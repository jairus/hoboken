<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
session_start();
class Home extends CI_Controller {
	
	public function __construct()
	{
		parent::__construct();
		$this->load->helper("functions");
		
	}
	
	public function index()
	{
		
		if($this->session->userdata('admin_user')){
			$session_data = $this->session->userdata('admin_user');
			
			$sql = "select * from `sites` where 1";
			$q = $this->db->query($sql);
			$sites = $q->result_array();
			$data = array();
			$data['username'] = $session_data['username'];
			$data['sites'] = $sites;
			$redirect = $this->load->view("homepage",$data);	
		}
		else{
			redirect(base_url());
		}		
	
	}
	
	public function delete($id){
		$sql = "delete from `sites` where `id`=".$this->db->escape(trim($id))."";
		$this->db->query($sql);
		redirect(base_url());
	}
	
	public function add()
	{
		if($this->session->userdata('admin_user')){
			$session_data = $this->session->userdata('admin_user');
			//create the site
			$err = "";
			$data = array();
			if($_POST){
				$sql = "select * from `sites` where `subdomain`=".$this->db->escape(trim($_POST['subdomain']))."";
				$q = $this->db->query($sql);
				$subdomain = $q->result_array();
				if(!checkSubdomain(trim($_POST['subdomain']))){
					$err = "Please Input a valid Subdomain.";
				}
				else if($subdomain[0]){
					$err = "Subdmain already exists in the database. Please input a new one.";
				}
				else if(!trim($_POST['title'])){
					$err = "Please Input Title.";
				}
				else if(!trim($_POST['admin_username'])){
					$err = "Please Input Admin Username.";
				}
				else if(!trim($_POST['admin_password'])){
					$err = "Please Input Admin Password.";
				}
				else if(!checkEmail($_POST['admin_email'])){
					$err = "Please Input a Valid Admin Email.";
				}
				if($err){
					$data = $_POST;
					$data['error'] = $err;
				}
				else{
					$sql = "insert into `sites` set ";
					$arr = array();
					foreach($_POST as $key=>$value){
						if(!is_array($value)){
							$arr[] ="`".$key."`=".$this->db->escape(trim($value));
						}
					}
					$sqlext = implode(", ", $arr);
					$sqlext = implode(", ", $arr);
					$sql .= $sqlext.", `dateadded`=NOW()";
					$q = $this->db->query($sql);
					$id = $this->db->insert_id();
					$data['success'] = "Successfully created subdomain!";
				}
			}
			
			
			$data['username'] = $session_data['username'];
			$redirect = $this->load->view("addpage",$data);	
		}
		else{
			redirect(base_url());
		}	
	}
	
	public function logout()
	{
		$this->session->unset_userdata('admin_user');
		session_destroy();
		redirect(base_url().'login');
	}
		
}
