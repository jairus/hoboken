<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Mommies247</title>
    
    <link type="text/css" rel="stylesheet" href="<?php echo base_url('media/css/style.css'); ?>" />
</head>
<body>

<div id="container">

	<div id="body">
		<?php $this->load->view($main_content)?>
	</div>

	
</div>

</body>
</html>
